# Changelog

## 0.1.1 · Milestone 1 overhaul

- Replaced the pilot with a proportioned human built from thirteen rigid bodies, including a pelvis and separate feet. Each joint has its own anchor and bending range. Passive angular resistance acts between segments. Floor placement uses the soles and settled humans sleep until disturbed.
- Preserved contacts between non-adjacent parts except where the side-view silhouettes overlap. Added smaller physics steps, continuous collision detection and capped, damped point dragging.
- Replaced chamber signage and striping with a charcoal backdrop, optional faint grid and plain floor. Added original pixel-cut clothing, hair and shoes, a narrower object library, closer default framing, cursor-centered zoom and rotation about the selection’s center of mass.
- Added a multi-human drop and drag test scene with per-frame anchor and floor measurements.

## 0.1.0 · Playable foundation

- Added the Relay Yard test chamber with original procedural artwork and four placeable object types.
- Added articulated passive pilots, physics dragging, whole-object freeze, rotation and deletion, camera controls, pause and confirmed reset.
- Added searchable placement controls and persistent gravity, grid, VSync and frame-cap settings.
- Added headless foundation checks and Windows x86-64 GitHub Actions export, packaging and launch validation.
